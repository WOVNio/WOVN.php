<?php

namespace Foo\Bar;

class Baz {}

namespace Other\Space;

class Extender extends \Foo\Bar\Baz {}

