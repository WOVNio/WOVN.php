<?php
namespace Foo\Bar
{
    class TestClassInBar
    {
    }
}

namespace Foo\Baz
{
    class TestClassInBaz
    {
    }
}
